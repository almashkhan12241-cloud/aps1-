AMAR PUBLIC SCHOOL - VERCEL DEPLOYMENT FIX

This package puts the website at the deployment root as index.html.

HOW TO DEPLOY:
1. Extract this ZIP on your computer.
2. In Vercel, open the correct Amar Public School project.
3. Open Settings > Build and Deployment.
4. For a plain HTML site, use Other as the Framework Preset, leave Build Command blank, and leave Output Directory blank (or set it to . if the dashboard requires a value).
5. Ensure Root Directory points to the folder containing index.html.
6. Redeploy the project.

If the old domain still shows 404, verify that this deployment belongs to the same project and that the domain is assigned to that project under Settings > Domains.
